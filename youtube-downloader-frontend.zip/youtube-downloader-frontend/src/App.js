import React, { useState } from 'react';

// Mock SVG Icons for demonstration
const CheckCircle = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);

const LinkIcon = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07L13 7.07a1 1 0 0 1 1.41 1.41L11.41 10a3 3 0 0 1-4.24-4.24l1.41-1.41a1 1 0 0 1 1.41 1.41z" />
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07L11 16.93a1 1 0 = 1-1.41-1.41L12.59 14a3 3 0 0 1 4.24 4.24l-1.41 1.41a1 1 0 0 1-1.41-1.41z" />
  </svg>
);

const Loader2 = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>;


function App() {
  const [videoUrl, setVideoUrl] = useState('');
  const [downloadStatus, setDownloadStatus] = useState(''); // 'idle', 'loading', 'success', 'error'
  const [errorMessage, setErrorMessage] = useState('');

  const handleDownload = async () => {
    if (!videoUrl) {
      setErrorMessage('Please enter a YouTube video URL.');
      setDownloadStatus('error');
      return;
    }
    setErrorMessage('');
    setDownloadStatus('loading');

    // This is the key change: Directly open a new window/tab to the backend's GET endpoint.
    // The backend's /download endpoint will now accept the URL as a query parameter.
    const downloadLink = `http://localhost:5000/download?url=${encodeURIComponent(videoUrl)}`;
    window.open(downloadLink, '_blank'); // Open in new tab to trigger download

    // Simulate success/error for frontend UI, as the actual download is handled by the browser
    // after window.open. We don't get direct feedback from window.open.
    setTimeout(() => {
        const isValidUrl = videoUrl.includes('youtube.com/watch?v=') || videoUrl.includes('youtu.be/');
        if (isValidUrl) {
            setDownloadStatus('success');
            setErrorMessage(''); // Clear any previous error messages
        } else {
            setErrorMessage('Invalid YouTube URL. Please check the format.');
            setDownloadStatus('error');
        }
    }, 500); // Short delay for UI feedback
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setVideoUrl(text);
      setDownloadStatus('idle'); // Reset status on paste
      setErrorMessage('');
    } catch (err) {
      setErrorMessage('Failed to read from clipboard. Please paste manually.');
      setDownloadStatus('error');
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4 font-inter bg-gray-900">
      {/* Background Gradient with Animation */}
      <style>
        {`
        @keyframes backgroundAnimation {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        .animated-gradient-background {
          background: linear-gradient(270deg, #6a11cb, #2575fc, #6a11cb);
          background-size: 600% 600%;
          animation: backgroundAnimation 20s ease infinite;
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
        }

        /* Add a subtle overlay for more depth */
        .animated-gradient-background::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
          opacity: 0.8;
          pointer-events: none;
        }

        /* Central gradient effect */
        .central-gradient-effect {
          background: linear-gradient(90deg, #FF0000, #FF7F00, #FFFF00, #00FF00, #0000FF, #4B0082, #9400D3);
          filter: blur(40px) opacity(0.6); /* Adjust blur and opacity for desired 'noisy' effect */
          border-radius: 9999px; /* Fully rounded */
          width: 100%;
          height: 100%;
          position: absolute;
          top: 0;
          left: 0;
        }
        `}
      </style>
      <div className="animated-gradient-background"></div>

      <div className="relative z-10 w-full max-w-2xl text-center">
        {/* Main Heading */}
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold mb-8 leading-tight" style={{
          background: 'linear-gradient(90deg, #FF0000, #FF7F00, #FFFF00, #00FF00, #0000FF, #4B0082, #9400D3)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}>
          Download Youtube Video by Link!
        </h1>

        {/* Features Section */}
        <div className="flex justify-center items-center space-x-6 mb-12 text-white text-lg md:text-xl">
          <div className="flex items-center">
            <CheckCircle className="w-6 h-6 text-green-400 mr-2" />
            <span>Unlimited Downloads</span>
          </div>
          <div className="flex items-center">
            <CheckCircle className="w-6 h-6 text-green-400 mr-2" />
            <span>No Watermark</span>
          </div>
        </div>

        {/* Input and Buttons Section */}
        <div className="relative flex flex-col md:flex-row items-center justify-center gap-4 px-4 py-4 rounded-full">
          {/* Central gradient effect behind the input and button */}
          <div className="central-gradient-effect"></div>

          <div className="relative flex-grow w-full md:w-auto z-20"> {/* z-20 to keep content above gradient */}
            <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="url"
              className="w-full pl-12 pr-4 py-4 rounded-full text-white text-lg placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 border border-transparent transition-all duration-300
                         bg-gray-800 bg-opacity-70" /* Adjusted background for input to see gradient through */
              placeholder="Paste your video link here..."
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              onFocus={() => {setDownloadStatus('idle'); setErrorMessage('')}}
            />
          </div>
          <button
            onClick={handleDownload}
            className="w-full md:w-auto px-8 py-4 rounded-full font-bold text-lg text-white shadow-lg transition-all duration-300 transform hover:scale-105
                       bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 flex items-center justify-center z-20" /* z-20 to keep content above gradient */
            disabled={downloadStatus === 'loading'}
          >
            {downloadStatus === 'loading' ? (
              <>
                <Loader2 className="animate-spin mr-3" />
                Processing...
              </>
            ) : (
              'Download'
            )}
          </button>
        </div>

        {/* Paste Button */}
        <div className="mt-4">
          <button
            onClick={handlePaste}
            className="px-6 py-2 rounded-full bg-gray-700 text-white text-md font-medium hover:bg-gray-600 transition-colors duration-300"
          >
            Paste
          </button>
        </div>

        {/* Status Messages */}
        {downloadStatus === 'success' && (
          <div className="mt-6 p-4 bg-green-500 bg-opacity-20 text-green-300 rounded-xl flex items-center justify-center text-base font-medium shadow-md mx-auto max-w-sm">
            <CheckCircle className="w-5 h-5 mr-2 text-green-400" />
            <p>Video link processed! Ready for download options.</p>
          </div>
        )}

        {downloadStatus === 'error' && errorMessage && (
          <div className="mt-6 p-4 bg-red-500 bg-opacity-20 text-red-300 rounded-xl flex items-center justify-center text-base font-medium shadow-md mx-auto max-w-sm">
            <p>{errorMessage}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
