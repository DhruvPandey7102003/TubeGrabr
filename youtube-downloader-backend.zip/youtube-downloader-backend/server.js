// server.js
const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process'); // Node.js built-in for spawning processes
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
    res.send('YouTube Downloader Backend (using yt-dlp via spawn) is running!');
});

// CHANGE: This endpoint now handles GET requests
app.get('/download', async (req, res) => {
    // CHANGE: Read videoUrl from query parameters for GET request
    const videoUrl = req.query.url;

    if (!videoUrl) {
        return res.status(400).send('Error: No URL provided.'); // Send plain text error for GET
    }

    const youtubeRegex = /(?:https?:\/\/)?(?:www\.)?(?:m\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=|embed\/|v\/|)([\w-]{11})(?:\S+)?/;
    if (!youtubeRegex.test(videoUrl)) {
        return res.status(400).send('Error: Invalid YouTube URL format.'); // Send plain text error for GET
    }

    try {
        // Get video info to extract title
        const info = await require('youtube-dl-exec').youtubeDl(videoUrl, {
            dumpSingleJson: true,
            noWarnings: true,
            noCheckCertificates: true,
            format: 'bestvideo[ext=mp4][vcodec^=avc]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        });

        const videoTitle = info.title ? info.title.replace(/[^\w\s.-]/g, '') : 'downloaded_video';
        const outputFilename = `${videoTitle}.mp4`;

        // Set response headers for direct download streaming
        res.header('Content-Disposition', `attachment; filename="${outputFilename}"`);
        res.header('Content-Type', 'video/mp4');

        // Arguments for yt-dlp command
        const ytDlpArgs = [
            videoUrl,
            '-f', 'bestvideo[ext=mp4][vcodec^=avc]+bestaudio[ext=m4a]/best[ext=mp4]/best', // Prioritize H.264 (avc) MP4 video
            '-o', '-', // Output to stdout
            '--no-warnings',
            '--no-check-certificates',
        ];

        // Spawn the yt-dlp process
        const ytDlpProcess = spawn('yt-dlp', ytDlpArgs);

        // Pipe stdout of yt-dlp to the Express response
        ytDlpProcess.stdout.pipe(res);

        // Capture stderr for debugging
        ytDlpProcess.stderr.on('data', (data) => {
            console.error(`yt-dlp stderr: ${data.toString()}`);
        });

        ytDlpProcess.on('error', (err) => {
            console.error('Failed to start yt-dlp process:', err);
            if (!res.headersSent) {
                res.status(500).send(`Error: Failed to start yt-dlp process. Details: ${err.message}`);
            } else {
                res.end();
            }
        });

        ytDlpProcess.on('close', (code) => {
            if (code !== 0) {
                console.error(`yt-dlp process exited with code ${code}`);
                if (!res.headersSent) {
                    res.status(500).send(`Error: yt-dlp process failed with code ${code}`);
                } else {
                    res.end();
                }
            } else {
                console.log('yt-dlp process finished successfully.');
                if (!res.headersSent) {
                    res.end();
                }
            }
        });

    } catch (error) {
        console.error('Backend error (catch block):', error);
        res.status(500).send(`Error: An internal server error occurred during processing. Details: ${error.message}`);
    }
});

app.listen(PORT, () => {
    console.log(`Node.js backend running on http://localhost:${PORT}`);
});
